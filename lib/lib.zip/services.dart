String initServer = 'www.babutik.com';
const String baseUrl = 'https://babutik.com/soko';
